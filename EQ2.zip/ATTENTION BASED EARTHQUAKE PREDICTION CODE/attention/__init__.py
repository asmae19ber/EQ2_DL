from attention.attention import Attention  # noqa
